#!/bin/bash
java -jar EncriptionPassword.jar
