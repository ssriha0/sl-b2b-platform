echo "Starting ServiceLive PCI Data Compare ::"
echo `date`

java -classpath exeKeyRotation.jar compare.Compare 2

echo `date`
