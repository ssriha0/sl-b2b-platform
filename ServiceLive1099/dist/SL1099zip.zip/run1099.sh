# SAMPLE ENTRIES java -jar exe1099.jar <P>/<F>
# The commmand has 1 parameter. P for PGP encryption. F for FTP. 
# as a general rule we always want to pass P - because of PGP encryption requirement.
java -jar exe1099.jar E