echo "Starting ServiceLive PCI Data Compare ::"
echo `date`

java -classpath tokenization.jar compare.Compare 2

echo `date`
